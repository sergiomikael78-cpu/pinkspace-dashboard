// ============================================================
// 🌸 Pink Password Generator Pro - Content Script
// Dashboard injection, password engine, and UI management
// ============================================================

(function () {
  'use strict';

  const CHARS = 'abcdefghijklmnopqrstuvwxyz0123456789';
  const MAX_HISTORY = 500;
  const CLEANUP_BATCH = 100;
  const MAX_GENERATE_ATTEMPTS = 150;

  const FORMAT_TEMPLATE =
    'Silakan di coba login bosku.\n' +
    'User ID : {userId}\n' +
    'Password : {password}\n\n' +
    'Silahkan lakukan copy lalu paste pada password tersebut ya bosku, agar Anda tidak kesulitan saat mencoba login bosku.\n\n' +
    'Catatan : Untuk keamanan akun Anda, kami sarankan untuk mengganti password dan menyimpannya di catatan Anda agar tidak terlupa.';

  let currentUserId = '';
  let currentPassword = '';
  let passwordLength = 8;
  let isGenerated = false;
  let toastTimer = null;

  let shadow = null;
  let el = {};

  // Resizing state
  let isDragging = false;
  let startX = 0;
  let startWidth = 0;
  let currentPanelWidth = 380;
  let isPanelVisible = true;

  function generateSecurePassword(length) {
    const array = new Uint32Array(length);
    crypto.getRandomValues(array);
    let result = '';
    for (let i = 0; i < length; i++) {
      result += CHARS[array[i] % CHARS.length];
    }
    return result;
  }

  function generateUniquePassword(length) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(['passwordHistory'], (data) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
          return;
        }

        const history = data.passwordHistory || [];
        const historySet = new Set(history);

        let password = '';
        let attempts = 0;

        do {
          password = generateSecurePassword(length);
          attempts++;

          if (attempts > MAX_GENERATE_ATTEMPTS) {
            const removeCount = Math.floor(history.length / 2);
            history.splice(0, removeCount);
            historySet.clear();
            history.forEach((p) => historySet.add(p));
            password = generateSecurePassword(length);
            break;
          }
        } while (historySet.has(password));

        history.push(password);

        if (history.length > MAX_HISTORY) {
          history.splice(0, CLEANUP_BATCH);
        }

        chrome.storage.local.set({ passwordHistory: history }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }
          resolve(password);
        });
      });
    });
  }

  function getPlainFormat(userId, password) {
    return FORMAT_TEMPLATE
      .replace('{userId}', userId)
      .replace('{password}', password);
  }

  function getDisplayHTML(userId, password) {
    const safeUserId = escapeHTML(userId);
    const safePassword = escapeHTML(password);

    return (
      '<span class="ppg-highlight-label">Silakan di coba login bosku.</span>\n' +
      '<span class="ppg-highlight-label">User ID : </span>' +
      '<span class="ppg-highlight-userid">' + safeUserId + '</span>\n' +
      '<span class="ppg-highlight-label">Password : </span>' +
      '<span class="ppg-highlight-password">' + safePassword + '</span>\n\n' +
      '<span class="ppg-highlight-label">Silahkan lakukan copy lalu paste pada password tersebut ya bosku, agar Anda tidak kesulitan saat mencoba login bosku.</span>\n\n' +
      '<span class="ppg-highlight-label">Catatan : Untuk keamanan akun Anda, kami sarankan untuk mengganti password dan menyimpannya di catatan Anda agar tidak terlupa.</span>'
    );
  }

  function escapeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function buildPetalsHTML(count) {
    let html = '';
    for (let i = 0; i < count; i++) {
      html += '<div class="ppg-petal"></div>';
    }
    return html;
  }

  function buildSparklesHTML(count) {
    let html = '';
    for (let i = 0; i < count; i++) {
      html += '<div class="ppg-sparkle"></div>';
    }
    return html;
  }

  function buildDashboardHTML() {
    return `
      <div class="ppg-panel" id="ppg-panel">
        <div class="ppg-resizer" id="ppg-resizer"></div>
        <div class="ppg-petals-container">${buildPetalsHTML(12)}</div>
        <div class="ppg-sparkles-container">${buildSparklesHTML(20)}</div>

        <div class="ppg-content">
          <!-- Header -->
          <div class="ppg-header">
            <div class="ppg-logo">🌸</div>
            <h1 class="ppg-title">MILA</h1>
            <p class="ppg-subtitle">Password Generator Pro Edition ✨</p>
          </div>
          <div class="ppg-divider"></div>

          <div class="ppg-section">
            <label class="ppg-label">
              <span class="ppg-label-icon">👤</span>
              User ID
            </label>
            <div class="ppg-input-wrapper">
              <input
                type="text"
                class="ppg-input"
                id="ppg-userid"
                placeholder="Enter User ID..."
                autocomplete="off"
                spellcheck="false"
              />
            </div>
          </div>

          <div class="ppg-section">
            <label class="ppg-label">
              <span class="ppg-label-icon">🔐</span>
              Password Length
            </label>
            <div class="ppg-slider-wrapper">
              <input
                type="range"
                class="ppg-slider"
                id="ppg-length"
                min="5"
                max="12"
                value="8"
              />
              <div class="ppg-slider-value" id="ppg-length-value">8</div>
            </div>
            <div class="ppg-slider-labels">
              <span>Min: 5</span>
              <span>Max: 12</span>
            </div>
          </div>

          <button class="ppg-btn ppg-btn-execute" id="ppg-execute">
            <span class="ppg-btn-sparkle">✨</span>
            Execute Generate
            <span class="ppg-btn-sparkle">✨</span>
          </button>

          <div class="ppg-section ppg-format-section">
            <label class="ppg-label">
              <span class="ppg-label-icon">📋</span>
              Preview Format
            </label>
            <div class="ppg-format-box" id="ppg-format-box">
              <div class="ppg-format-placeholder" id="ppg-format-placeholder">
                Click "Execute Generate" to preview the format
              </div>
              <div class="ppg-format-text" id="ppg-format-text" style="display:none;"></div>
            </div>
          </div>

          <div class="ppg-actions">
            <button class="ppg-btn ppg-btn-copy" id="ppg-copy" disabled>
              📋 Copy Format
            </button>
            <button class="ppg-btn ppg-btn-regen" id="ppg-regen" disabled>
              🔄 Re-Generate
            </button>
          </div>

          <div class="ppg-stats">
            <div class="ppg-stat">
              <span class="ppg-stat-value" id="ppg-total">0</span>
              <span class="ppg-stat-label">Total Generated</span>
            </div>
            <div class="ppg-stat">
              <span class="ppg-stat-value" id="ppg-today">0</span>
              <span class="ppg-stat-label">Today</span>
            </div>
          </div>

          <div class="ppg-version">v1.0.0 • MILA Pro Edition</div>
        </div>
      </div>

      <button class="ppg-toggle" id="ppg-toggle" title="Toggle Password Generator">
        <span class="ppg-toggle-icon">›</span>
      </button>

      <div class="ppg-toast" id="ppg-toast"></div>
    `;
  }

  function setupEventListeners() {
    el.slider.addEventListener('input', () => {
      passwordLength = parseInt(el.slider.value, 10);
      el.sliderValue.textContent = passwordLength;
      updateSliderTrack();
    });

    el.executeBtn.addEventListener('click', handleGenerate);
    el.copyBtn.addEventListener('click', handleCopy);
    el.regenBtn.addEventListener('click', handleRegenerate);
    el.toggleBtn.addEventListener('click', handleToggle);

    // Resizer logic
    el.resizer.addEventListener('mousedown', (e) => {
      isDragging = true;
      startX = e.clientX;
      startWidth = currentPanelWidth;
      el.resizer.classList.add('is-resizing');
      document.body.classList.add('ppg-resizing-active'); // To prevent text selection globally
      
      // We add temporary event listeners to the window/document so drag works smoothly even outside the panel
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    });

    el.userIdInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleGenerate();
      }
    });

    el.userIdInput.addEventListener('focus', () => {
      el.userIdInput.classList.remove('ppg-input-error');
    });

    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'togglePanel') {
        if (message.visible) {
          el.panel.classList.remove('ppg-collapsed');
          el.toggleBtn.classList.remove('ppg-toggle-collapsed');
        } else {
          el.panel.classList.add('ppg-collapsed');
          el.toggleBtn.classList.add('ppg-toggle-collapsed');
        }
      }
    });
  }

  async function handleGenerate() {
    const userId = el.userIdInput.value.trim();

    if (!userId) {
      showToast('⚠️ Please enter a User ID first!');
      el.userIdInput.classList.add('ppg-input-error');
      el.userIdInput.focus();
      return;
    }

    el.executeBtn.disabled = true;
    el.executeBtn.innerHTML =
      '<span class="ppg-btn-sparkle">⏳</span> Generating... <span class="ppg-btn-sparkle">⏳</span>';

    try {
      currentUserId = userId;
      currentPassword = await generateUniquePassword(passwordLength);
      updateFormatDisplay();
      el.copyBtn.disabled = false;
      el.regenBtn.disabled = false;
      await updateStats();
      isGenerated = true;
      showToast('✨ Password generated successfully!');
    } catch (error) {
      console.error('🌸 MILA Error:', error);
      showToast('❌ Error generating password. Please try again.');
    } finally {
      el.executeBtn.disabled = false;
      el.executeBtn.innerHTML =
        '<span class="ppg-btn-sparkle">✨</span> Execute Generate <span class="ppg-btn-sparkle">✨</span>';
    }
  }

  async function handleRegenerate() {
    if (!currentUserId) return;

    el.regenBtn.disabled = true;
    const originalText = el.regenBtn.innerHTML;
    el.regenBtn.innerHTML = '⏳ Generating...';

    try {
      currentPassword = await generateUniquePassword(passwordLength);
      updateFormatDisplay();
      await updateStats();
      showToast('🔄 Password re-generated successfully!');
    } catch (error) {
      console.error('🌸 MILA Error:', error);
      showToast('❌ Error. Please try again.');
    } finally {
      el.regenBtn.disabled = false;
      el.regenBtn.innerHTML = originalText;
    }
  }

  async function handleCopy() {
    if (!currentUserId || !currentPassword) return;

    const formatText = getPlainFormat(currentUserId, currentPassword);

    try {
      await navigator.clipboard.writeText(formatText);
      onCopySuccess();
    } catch (err) {
      try {
        const 本 = document.createElement('textarea');
        本.value = formatText;
        本.style.cssText = 'position:fixed;left:-9999px;top:-9999px;opacity:0;';
        document.body.appendChild(本);
        本.select();
        本.setSelectionRange(0, 本.value.length);
        document.execCommand('copy');
        document.body.removeChild(本);
        onCopySuccess();
      } catch (err2) {
        console.error('🌸 MILA Copy Error:', err2);
        showToast('❌ Failed to copy. Please try manually.');
      }
    }
  }

  function onCopySuccess() {
    el.copyBtn.classList.add('ppg-copied');
    el.copyBtn.innerHTML = '✅ Copied!';
    createConfetti();
    showToast('📋 Format copied to clipboard!');
    setTimeout(() => {
      el.copyBtn.classList.remove('ppg-copied');
      el.copyBtn.innerHTML = '📋 Copy Format';
    }, 2200);
  }

  function handleMouseMove(e) {
    if (!isDragging) return;
    
    // The panel is on the right, so moving left (negative delta) means WIDER panel.
    const deltaX = startX - e.clientX;
    let newWidth = startWidth + deltaX;
    
    // Constraints
    if (newWidth < 280) newWidth = 280;
    if (newWidth > 600) newWidth = 600;
    
    updatePanelWidth(newWidth);
  }

  function handleMouseUp() {
    if (!isDragging) return;
    isDragging = false;
    el.resizer.classList.remove('is-resizing');
    document.body.classList.remove('ppg-resizing-active');
    
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
    
    // Save to storage
    chrome.storage.local.set({ ppgPanelWidth: currentPanelWidth });
  }

  function updatePanelWidth(width) {
    currentPanelWidth = width;
    
    // Update CSS variable in shadow host
    shadow.host.style.setProperty('--ppg-panel-width', `${width}px`);
    
    // Update host body padding dynamically if panel is visible
    if (isPanelVisible) {
      document.body.style.paddingRight = `${width}px`;
      document.body.style.transition = 'padding-right 0s'; // Instant during drag
    }
  }

  function handleToggle() {
    const isCollapsed = el.panel.classList.toggle('ppg-collapsed');
    el.toggleBtn.classList.toggle('ppg-toggle-collapsed', isCollapsed);
    isPanelVisible = !isCollapsed;
    
    // Adjust host page padding with transition
    document.body.style.transition = 'padding-right 0.4s ease';
    if (isPanelVisible) {
      document.body.style.paddingRight = `${currentPanelWidth}px`;
    } else {
      document.body.style.paddingRight = '0px';
    }
    
    chrome.storage.local.set({ panelVisible: isPanelVisible });
  }

  function updateFormatDisplay() {
    el.formatPlaceholder.style.display = 'none';
    el.formatText.style.display = 'block';
    el.formatText.innerHTML = getDisplayHTML(currentUserId, currentPassword);
  }

  function updateSliderTrack() {
    const percentage = ((passwordLength - 5) / (12 - 5)) * 100;
    el.slider.style.background =
      `linear-gradient(90deg, #ff69b4 0%, #ff1493 ${percentage}%, rgba(255, 105, 180, 0.15) ${percentage}%)`;
  }

  function updateStats() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'updateStats' }, (stats) => {
        if (chrome.runtime.lastError) {
          console.warn('🌸 MILA Stats Error:', chrome.runtime.lastError);
          resolve();
          return;
        }
        if (stats) {
          el.totalStat.textContent = stats.totalGenerated;
          el.todayStat.textContent = stats.todayGenerated;
        }
        resolve();
      });
    });
  }

  function loadStats() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'getStats' }, (stats) => {
        if (chrome.runtime.lastError) {
          console.warn('🌸 MILA Stats Error:', chrome.runtime.lastError);
          resolve();
          return;
        }
        if (stats) {
          el.totalStat.textContent = stats.totalGenerated;
          el.todayStat.textContent = stats.todayGenerated;
        }
        resolve();
      });
    });
  }

  function showToast(message) {
    if (toastTimer) clearTimeout(toastTimer);

    el.toast.textContent = message;
    el.toast.classList.add('ppg-toast-show');

    toastTimer = setTimeout(() => {
      el.toast.classList.remove('ppg-toast-show');
      toastTimer = null;
    }, 2800);
  }

  function createConfetti() {
    const container = document.createElement('div');
    container.className = 'ppg-confetti-container';
    shadow.querySelector('.ppg-panel').appendChild(container);

    const colors = [
      '#ff69b4', '#ff1493', '#ffd700',
      '#ffb6c1', '#ff85c2', '#c2185b',
      '#ffcce0', '#e040fb', '#ff80ab'
    ];

    const btnRect = el.copyBtn.getBoundingClientRect();
    const panelRect = el.panel.getBoundingClientRect();

    const startX = btnRect.left - panelRect.left + btnRect.width / 2;
    const startY = btnRect.top - panelRect.top;

    for (let i = 0; i < 24; i++) {
      const piece = document.createElement('div');
      piece.className = 'ppg-confetti';

      const size = 4 + Math.random() * 6;
      const offsetX = (Math.random() - 0.5) * 120;

      piece.style.cssText = `
        left: ${startX + offsetX}px;
        top: ${startY}px;
        width: ${size}px;
        height: ${size * 0.6}px;
        background: ${colors[Math.floor(Math.random() * colors.length)]};
        animation-delay: ${Math.random() * 0.35}s;
        animation-duration: ${1.2 + Math.random() * 0.8}s;
      `;

      container.appendChild(piece);
    }

    setTimeout(() => container.remove(), 2500);
  }

  function injectDashboard() {
    if (document.getElementById('ppg-host')) {
      console.log('🌸 MILA already injected.');
      return;
    }

    const host = document.createElement('div');
    host.id = 'ppg-host';
    host.style.cssText =
      'all:initial; position:fixed; top:0; right:0; z-index:2147483647; pointer-events:none;';
    document.body.appendChild(host);

    shadow = host.attachShadow({ mode: 'closed' });

    const linkEl = document.createElement('link');
    linkEl.rel = 'stylesheet';
    linkEl.href = chrome.runtime.getURL('content.css');
    shadow.appendChild(linkEl);

    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'pointer-events:auto;';
    wrapper.innerHTML = buildDashboardHTML();
    shadow.appendChild(wrapper);

    el = {
      panel: shadow.querySelector('#ppg-panel'),
      userIdInput: shadow.querySelector('#ppg-userid'),
      slider: shadow.querySelector('#ppg-length'),
      sliderValue: shadow.querySelector('#ppg-length-value'),
      executeBtn: shadow.querySelector('#ppg-execute'),
      formatBox: shadow.querySelector('#ppg-format-box'),
      formatPlaceholder: shadow.querySelector('#ppg-format-placeholder'),
      formatText: shadow.querySelector('#ppg-format-text'),
      copyBtn: shadow.querySelector('#ppg-copy'),
      regenBtn: shadow.querySelector('#ppg-regen'),
      toggleBtn: shadow.querySelector('#ppg-toggle'),
      totalStat: shadow.querySelector('#ppg-total'),
      todayStat: shadow.querySelector('#ppg-today'),
      toast: shadow.querySelector('#ppg-toast'),
      resizer: shadow.querySelector('#ppg-resizer')
    };

    setupEventListeners();
    updateSliderTrack();
    loadStats();

    // Prevent LiveChat body transition from feeling jumpy when loading initially
    document.body.style.transition = 'padding-right 0.4s ease';

    chrome.storage.local.get(['panelVisible', 'ppgPanelWidth'], (data) => {
      if (data.ppgPanelWidth) {
        currentPanelWidth = data.ppgPanelWidth;
      }
      
      shadow.host.style.setProperty('--ppg-panel-width', `${currentPanelWidth}px`);

      if (data.panelVisible === false) {
        isPanelVisible = false;
        el.panel.classList.add('ppg-collapsed');
        el.toggleBtn.classList.add('ppg-toggle-collapsed');
        document.body.style.paddingRight = '0px';
      } else {
        isPanelVisible = true;
        document.body.style.paddingRight = `${currentPanelWidth}px`;
      }
    });

    if (!document.querySelector('link[href*="fonts.googleapis.com"][href*="Inter"]')) {
      const fontLink = document.createElement('link');
      fontLink.rel = 'stylesheet';
      fontLink.href =
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap';
      document.head.appendChild(fontLink);
    }

    console.log('🌸 MILA Pro Edition loaded successfully!');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(injectDashboard, 800);
    });
  } else {
    setTimeout(injectDashboard, 1200);
  }
})();
