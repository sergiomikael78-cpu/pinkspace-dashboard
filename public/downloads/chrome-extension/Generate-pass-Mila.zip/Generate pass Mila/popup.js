// ============================================================
// 🌸 Pink Password Generator Pro - Popup Script
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  const toggleVisible = document.getElementById('toggle-visible');
  const totalEl = document.getElementById('popup-total');
  const todayEl = document.getElementById('popup-today');

  chrome.storage.local.get(['panelVisible', 'stats'], (data) => {
    toggleVisible.checked = data.panelVisible !== false;
    const stats = data.stats || {
      totalGenerated: 0,
      todayGenerated: 0,
      todayDate: ''
    };
    const today = new Date().toISOString().split('T')[0];

    totalEl.textContent = stats.totalGenerated || 0;
    todayEl.textContent = (stats.todayDate === today)
      ? (stats.todayGenerated || 0)
      : 0;
  });

  toggleVisible.addEventListener('change', (e) => {
    const visible = e.target.checked;
    chrome.storage.local.set({ panelVisible: visible });

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url && tabs[0].url.includes('my.livechatinc.com')) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'togglePanel',
          visible: visible
        }).catch(() => {
          console.log('Content script not available on this tab');
        });
      }
    });
  });
});
