// ============================================================
// 🌸 Pink Password Generator Pro - Background Service Worker
// ============================================================

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.storage.local.set({
      passwordHistory: [],
      stats: {
        totalGenerated: 0,
        todayGenerated: 0,
        todayDate: new Date().toISOString().split('T')[0]
      },
      panelVisible: true,
      defaultLength: 8
    });
    console.log('🌸 Pink Password Generator Pro installed successfully!');
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'getStats':
      chrome.storage.local.get(['stats'], (data) => {
        const stats = data.stats || {
          totalGenerated: 0,
          todayGenerated: 0,
          todayDate: ''
        };
        const today = new Date().toISOString().split('T')[0];
        if (stats.todayDate !== today) {
          stats.todayDate = today;
          stats.todayGenerated = 0;
          chrome.storage.local.set({ stats });
        }
        sendResponse(stats);
      });
      return true;

    case 'updateStats':
      chrome.storage.local.get(['stats'], (data) => {
        const stats = data.stats || {
          totalGenerated: 0,
          todayGenerated: 0,
          todayDate: ''
        };
        const today = new Date().toISOString().split('T')[0];
        if (stats.todayDate !== today) {
          stats.todayDate = today;
          stats.todayGenerated = 0;
        }
        stats.totalGenerated++;
        stats.todayGenerated++;
        chrome.storage.local.set({ stats }, () => {
          sendResponse(stats);
        });
      });
      return true;

    case 'getHistory':
      chrome.storage.local.get(['passwordHistory'], (data) => {
        sendResponse(data.passwordHistory || []);
      });
      return true;

    case 'clearHistory':
      chrome.storage.local.set({ passwordHistory: [] }, () => {
        sendResponse({ success: true });
      });
      return true;

    default:
      break;
  }
});
