// <!-- Ini Baris Script Scatter -->

// --- LOGIKA KHUSUS SCATTER ---
const pendingBatchRequests = new Map();

// 1. Fungsi Ganti Tab
function openTab(tabId, el) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    
    document.getElementById(tabId).classList.add('active');
    if (el) el.classList.add('active');
}

document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("clearBtn").addEventListener("click", clearHistoryBatch);
    document.getElementById("processSingleBtn").addEventListener("click", startProcessingSingle);
    document.getElementById("processBatchBtn").addEventListener("click", startProcessingBatch);
    document.getElementById("copyBtnBatch").addEventListener("click", copyResultBatch);

    document.querySelectorAll(".tab-btn[data-tab]").forEach((btn) => {
        btn.addEventListener("click", () => openTab(btn.dataset.tab, btn));
    });

    document.getElementById("tableBodyBatch").addEventListener("click", (event) => {
        const btn = event.target.closest(".btn-recheck");
        if (!btn) return;
        reProcessSingle(btn.dataset.sid);
    });

    const now = new Date();
    const offset = now.getTimezoneOffset() * 60000;
    const localISOTime = (new Date(now - offset)).toISOString().split('T')[0];
    document.getElementById('inputDate').value = localISOTime;
    loadHistoryBatch();
});

// 2. Proses Single
async function startProcessingSingle() {
    const dateVal = document.getElementById('inputDate').value; 
    const mId = document.getElementById('inputUserId').value.trim();
    const sId = document.getElementById('inputTicketId').value.trim();

    if (!dateVal || !mId || !sId) return alert("Lengkapi data!");

    const payload = { targetDate: dateVal, mId: mId, sId: sId };
    pendingBatchRequests.set(sId, true);
    processViaBackground(payload);
    
    document.getElementById('inputUserId').value = "";
    document.getElementById('inputTicketId').value = "";
    document.getElementById('statusBatch').innerHTML = `🚀 ${mId} ditambahkan ke antrean...`;
}

// 3. Proses Batch
async function startProcessingBatch() {
    const input = document.getElementById('bulkInput').value.trim();
    if (!input) return alert("Input kosong!");

    const rows = input.split('\n').filter(r => r.trim() !== "");
    document.getElementById('statusBatch').innerHTML = `🚀 Memproses ${rows.length} data antrean...`;

    rows.forEach(row => {
        const parts = row.trim().split(/\s+/);
        if (parts.length >= 5) {
            const payload = {
                targetDate: parseDateBatch(parts[0], parts[1], parts[2]),
                mId: parts[3],
                sId: parts[4]
            };
            pendingBatchRequests.set(payload.sId, true);
            processViaBackground(payload);
        }
    });
    document.getElementById('bulkInput').value = "";
}

// 4. Komunikasi dengan background extension
function processViaBackground(payload) {
    if (!chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
        alert("Halaman ini harus dijalankan dari Chrome Extension, bukan dibuka langsung sebagai file HTML.");
        return;
    }

    chrome.runtime.sendMessage({ action: "PROCESS_DATA", payload }, (resp) => {
        if (chrome.runtime.lastError) {
            renderRowBatch({
                time: new Date().toLocaleTimeString(),
                mId: payload.mId || "-",
                sId: payload.sId,
                bet: "0",
                scatter: "-",
                statusBonus: `Gagal: ${chrome.runtime.lastError.message}`,
                date: payload.targetDate
            });
            return;
        }
        handleExtensionResponse(resp);
    });
}

function handleExtensionResponse(resp) {
    if (!resp) return;

    // Support response from the old GAS bridge and direct messages from this extension background.
    if (resp.action === "BATCH_ITEM_DONE") {
        resp = { type: "FROM_EXTENSION", response: resp.result };
    }

    if (resp.type !== "FROM_EXTENSION") return;

    const response = resp.response || {};
    const sId = response.sId || (response.data && response.data.sId);
    if (!sId) return;

    if (response.data && response.data.isBonusInput) {
        updateDashboardStatusUIBatch(sId, response.data.statusBonus);
        return;
    }

    if (pendingBatchRequests.has(sId)) {
        pendingBatchRequests.delete(sId);
        if (response.success) {
            const actualData = response.data || {};
            const scatterVal = actualData.scatter || "0";
            const displayData = {
                time: actualData.time || new Date().toLocaleTimeString(),
                mId: actualData.mId || "-",
                sId: sId,
                bet: actualData.bet || "0",
                scatter: scatterVal,
                statusBonus: (scatterVal !== "0" && scatterVal !== "-") ? "Proses Input..." : "-",
                date: actualData.targetDate || actualData.date
            };
            renderRowBatch(displayData);
            saveToLocalBatch(displayData);
        } else {
            renderRowBatch({
                time: new Date().toLocaleTimeString(),
                mId: response.mId || "-",
                sId: sId,
                bet: "0",
                scatter: "-",
                statusBonus: `Gagal: ${response.error || "Unknown error"}`,
                date: response.targetDate
            });
        }
    }
}

// Listener tambahan kalau background mengirim update status bonus terpisah
chrome.runtime.onMessage.addListener((msg) => {
    handleExtensionResponse(msg);
});


function renderRowBatch(data, shouldSave = true) {
    const tableBody = document.getElementById('tableBodyBatch');
    let existingRow = document.querySelector(`tr[data-sid="${data.sId}"]`);
    if (existingRow) existingRow.remove();

    const isScatter = data.scatter !== "0" && data.scatter !== "-";
    const html = `
        <tr data-sid="${data.sId}">
            <td style="text-align:center">${data.time}</td>
            <td>${data.mId}</td>
            <td style="font-family:monospace">${data.sId}</td>
            <td style="text-align:right">${Number(data.bet).toLocaleString()}</td>
            <td style="text-align:center" class="${isScatter ? 'sc-found' : ''}">${data.scatter}</td>
            <td class="status-col-batch" style="text-align:center">${data.statusBonus || "Menunggu..."}</td>
            <td class="aksi-col-batch" style="text-align:center">-</td>
        </tr>
    `;
    tableBody.insertAdjacentHTML('afterbegin', html);
    document.getElementById('copyBtnBatch').style.display = 'block';
    
    // Update warna dan tombol aksi
    updateDashboardStatusUIBatch(data.sId, data.statusBonus || "-");
    
    // Hanya simpan ke storage jika ini data baru dari extension, bukan dari load history
    if (shouldSave) {
        saveToLocalBatch(data);
    }
    
    
}

function updateDashboardStatusUIBatch(sId, statusText) {
    const row = document.querySelector(`tr[data-sid="${sId}"]`);
    if (!row) return;

    const statusCell = row.querySelector('.status-col-batch');
    const actionCell = row.querySelector('.aksi-col-batch');
    
    statusCell.innerText = statusText;
    const lower = statusText.toLowerCase();

    // Logika Warna Status
    if (lower.includes("sukses") || lower.includes("input")) {
        statusCell.style.color = "#28a745"; // Hijau sukses
    } else if (lower.includes("sudah") || lower.includes("klaim")) {
        statusCell.style.color = "orange";
    } else if (lower.includes("gagal") || lower.includes("error")) {
        statusCell.style.color = "#dc3545"; // Merah bahaya
    }

    // Logika Tombol Re-Check
    if (!lower.includes("sukses") && !lower.includes("sudah") && !lower.includes("max")) {
        actionCell.innerHTML = `<button class="btn-recheck" data-sid="${sId}">RE-CHECK</button>`;
    } else {
        actionCell.innerHTML = "-";
    }

    // --- BAGIAN PENTING: UPDATE STORAGE SAAT STATUS BERUBAH ---
    let history = JSON.parse(localStorage.getItem("rampoz_history") || "[]");
    const idx = history.findIndex(h => h.sId === sId);
    if (idx > -1) {
        history[idx].statusBonus = statusText; // Update status terbaru ke objek history
        localStorage.setItem("rampoz_history", JSON.stringify(history));
    }
}

function reProcessSingle(sId) {
    const history = JSON.parse(localStorage.getItem("rampoz_history") || "[]");
    const data = history.find(h => h.sId === sId);
    if (!data) return alert("Data tidak ditemukan!");

    updateDashboardStatusUIBatch(sId, "Memproses Ulang...");
    pendingBatchRequests.set(sId, true);
    processViaBackground({
        targetDate: data.date || new Date().toISOString().split('T')[0],
        mId: data.mId,
        sId: sId
    });
}

function parseDateBatch(d, m, y) {
    const months = { jan:"01", feb:"02", mar:"03", apr:"04", mei:"05", may:"05", jun:"06", jul:"07", ags:"08", aug:"08", sep:"09", okt:"10", oct:"10", nov:"11", des:"12", dec:"12" };
    return `${y}-${months[m.toLowerCase().substring(0,3)] || "01"}-${d.padStart(2, '0')}`;
}

function saveToLocalBatch(data) {
    let history = JSON.parse(localStorage.getItem("rampoz_history") || "[]");
    const idx = history.findIndex(h => h.sId === data.sId);
    
    if (idx > -1) {
        history[idx] = data; 
    } else {
        history.push(data);
    }
    
    // Simpan maksimal 100 data terbaru
    localStorage.setItem("rampoz_history", JSON.stringify(history.slice(-100)));
}

function loadHistoryBatch() {
    const history = JSON.parse(localStorage.getItem("rampoz_history") || "[]");
    const tableBody = document.getElementById('tableBodyBatch');
    tableBody.innerHTML = ""; 
    
    // Gunakan slice().reverse() jika ingin data terbaru tetap di atas saat refresh
    history.forEach(data => {
        renderRowBatch(data, false); 
        // Pastikan update UI dipanggil agar warna status muncul kembali
        updateDashboardStatusUIBatch(data.sId, data.statusBonus || "-");
    });
}

function clearHistoryBatch() {
    if(confirm("Hapus semua data tabel?")) {
        localStorage.removeItem("rampoz_history");
        document.getElementById('tableBodyBatch').innerHTML = "";
        document.getElementById('copyBtnBatch').style.display = "none";
    }
}

function copyResultBatch() {
    const history = JSON.parse(localStorage.getItem("rampoz_history") || "[]");
    const text = history.map(d => `${d.mId}\t${d.sId}\t.\t${d.bet}\t${d.scatter}`).join('\n');
    navigator.clipboard.writeText(text);
    alert("Data laporan disalin!");
}

// <!-- Ini Batas Baris Scatter -->