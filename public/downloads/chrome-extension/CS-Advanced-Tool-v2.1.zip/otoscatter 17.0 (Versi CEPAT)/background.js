console.log("🔥 SERVICE WORKER AKTIF");

let dataQueue = [];
let isProcessing = false;
const BATCH_LIMIT = 5; 
let activeJobsCount = 0; 
let keepAliveInterval;

// --- UTILITIES ---
function startKeepAlive() {
  if (keepAliveInterval) return;
  keepAliveInterval = setInterval(() => {
    console.log("🔄 keeping service worker alive");
  }, 20000);
}

function stopKeepAlive() {
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
    keepAliveInterval = null;
  }
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "keepAlive") {
    startKeepAlive();
    port.onDisconnect.addListener(() => stopKeepAlive());
  }
});

// --- HEADER SNIFFER (PERBAIKAN UTAMA) ---
// Letakkan di top-level, jangan di dalam fungsi lain
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const headers = details.requestHeaders;
    const authHeader = headers.find(h => h.name.toLowerCase() === 'x-access-token');
    
    if (authHeader) {
      const extractedData = {
        token: authHeader.value,
        userid: headers.find(h => h.name.toLowerCase() === 'x-agent-userid')?.value,
        pkid: headers.find(h => h.name.toLowerCase() === 'x-agent-pkid')?.value,
        role: headers.find(h => h.name.toLowerCase() === 'x-agent-role')?.value,
        suid: headers.find(h => h.name.toLowerCase() === 'x-agent-suid')?.value,
        userAgent: headers.find(h => h.name.toLowerCase() === 'x-agent-user')?.value
      };

      // Simpan otomatis ke storage
      chrome.storage.local.set(extractedData, () => {
        console.log("✅ Headers Grabbed!");
      });
    }
  },
  { urls: ["*://*.idrbo.com/*", "*://*.jutawanbet.idrbo.com/*"] },
  ["requestHeaders", "extraHeaders"] // WAJIB ada extraHeaders
);

// --- MESSAGE LISTENER ---
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.action === "OPEN_DASHBOARD") {
    chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
    sendResponse({ success: true });
  }

  if (request.action === "CLOSE_BONUS_TAB") {
    if (sender.tab?.id) chrome.tabs.remove(sender.tab.id);
  }

  if (request.action === "PROCESS_DATA" || request.type === "PROCESS_DATA") {
    dataQueue.push(request.payload);
    console.log(`📥 Data ditambahkan. Total antrean: ${dataQueue.length}`);
    sendResponse({ success: true, status: "queued", sId: request.payload.sId });
    if (!isProcessing) processQueue();
  }
  
  if (request.action === "update_final_sheet") {
    broadcastResult({
      success: true,
      sId: request.timestampId,
      status: "completed",
      data: { statusBonus: request.statusTeks || "Gagal Ambil Status", isBonusInput: true }
    });
    sendResponse({ success: true });
  }
  return true; 
});

// --- BATCH PROCESSOR ---
async function processQueue() {
  if (dataQueue.length === 0 && activeJobsCount === 0) {
    isProcessing = false;
    stopKeepAlive();
    return;
  }
  
  isProcessing = true;
  startKeepAlive();

  while (dataQueue.length > 0 && activeJobsCount < BATCH_LIMIT) {
    const payload = dataQueue.shift();
    activeJobsCount++; 
    runSingleTask(payload);
  }
}

async function runSingleTask(payload) {
  try {
    await new Promise(r => setTimeout(r, Math.random() * 2000));

    const res = await chrome.storage.local.get(["extensionEnabled", "targetDomain"]);

    if (res.extensionEnabled === false) {
      broadcastResult({
        success: false,
        mId: payload.mId,
        sId: payload.sId,
        status: "failed",
        error: "Extension OFF",
        data: {
          mId: payload.mId,
          sId: payload.sId,
          bet: payload.debet || "",
          scatter: "",
          error: "Extension OFF",
          statusText: "Extension OFF"
        }
      });
      return;
    }

    const resultData = await mainProcessor(payload, res.targetDomain);

    broadcastResult({
      success: true,
      sId: payload.sId,
      status: "completed",
      targetDate: payload.targetDate,
      data: resultData
    });

    if (/\d/.test(String(resultData.scatter)) && String(resultData.scatter) !== "0") {
      inputToBonusDashboard(resultData);
    }

  } catch (err) {
    console.error(`❌ Gagal SID ${payload.sId}:`, err.message);

    broadcastResult({
      success: false,
      mId: payload.mId,
      sId: payload.sId,
      status: "failed",
      error: err.message,
      data: {
        mId: payload.mId,
        sId: payload.sId,
        bet: payload.debet || "",
        scatter: "",
        targetDate: payload.targetDate,
        error: err.message,
        statusText: err.message
      }
    });

  } finally {
    activeJobsCount--;
    processQueue();
  }
}

// --- LOGIC UTAMA (MAIN PROCESSOR) ---
async function mainProcessor(payload, customDomain) {
    const { mId, sId, targetDate } = payload;
      
      // Ambil header dari storage yang tadi sudah di-grab otomatis
      const data = await chrome.storage.local.get(["token", "userid", "pkid", "role", "suid", "userAgent", "targetDomain"]);
      
      let domain = (data.targetDomain || "ag-jutawanbet.idrbo.com").replace(/^(https?:\/\/)/, "").split('/')[0];
      const adminUrl = `https://${domain}/game-oc/ida/transaction/history/queryTransactionHistoryListForUser?userId=${mId}&startDate=${targetDate}&endDate=${targetDate}&transactionId=${sId}`;

      // Masukkan header secara eksplisit di sini
      const adminRes = await fetch(adminUrl, {
        method: 'GET',
        headers: {
          "X-Access-Token": data.token,
          "X-Agent-Pkid": data.pkid,
          "X-Agent-Role": data.role,
          "X-Agent-Suid": data.suid,
          "X-Agent-User": data.userAgent,
          "X-Agent-UserId": data.userid
        }
      });
  if (!adminRes.ok) throw new Error("Gagal akses Admin (Cek Token)");
  const adminData = await adminRes.json();
  const record = adminData.result?.records?.find(item => item.debet > 0);
  if (!record) throw new Error("Transaksi debet tidak ditemukan");
  const gameId = record.gameName.split(':')[1] || record.gameName;
  const token = await getAutoTokenInternal(mId, sId, gameId, domain);
  if (!token) throw new Error("Err Token");
  await new Promise(resolve => setTimeout(resolve, 2500));
  const pgUrl = `https://public-api.zmcyu9ypy.com/web-api/operator-proxy/v1/History/GetBetHistory?t=${token}`;
  const pgRes = await fetch(pgUrl, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `sid=${sId}&gid=${gameId}`
  });
  const pgData = await pgRes.json();
  let finalSC = "0";
  if (pgData?.dt?.bh?.bd) {
    const scatterTrigger = pgData.dt.bh.bd.find(item => item.gd && item.gd.nst === 21);
    if (scatterTrigger) finalSC = scatterTrigger.gd.sc || "0";
  }
  return { mId, sId, bet: record.debet, scatter: scaterVal, time: record.tanggal };
}


async function mainProcessor(payload, customDomain) {
  const { mId, sId, targetDate } = payload;

  const data = await chrome.storage.local.get([
    "token",
    "userid",
    "pkid",
    "role",
    "suid",
    "userAgent",
    "targetDomain"
  ]);

  let domain = (data.targetDomain || customDomain || "ag-jutawanbet.idrbo.com")
    .replace(/^(https?:\/\/)/, "")
    .split("/")[0];

  const adminUrl =
    `https://${domain}/game-oc/ida/transaction/history/queryTransactionHistoryListForUser` +
    `?userId=${encodeURIComponent(mId)}` +
    `&startDate=${encodeURIComponent(targetDate)}` +
    `&endDate=${encodeURIComponent(targetDate)}` +
    `&transactionId=${encodeURIComponent(sId)}`;

  const adminRes = await fetch(adminUrl, {
    method: "GET",
    headers: {
      "X-Access-Token": data.token,
      "X-Agent-Pkid": data.pkid,
      "X-Agent-Role": data.role,
      "X-Agent-Suid": data.suid,
      "X-Agent-User": data.userAgent,
      "X-Agent-UserId": data.userid
    }
  });

  if (!adminRes.ok) {
    throw new Error("Gagal akses Admin (Cek Token)");
  }

  const adminData = await adminRes.json();

  const record = adminData.result?.records?.find(item => Number(item.debet) > 0);

  if (!record) {
    throw new Error("Transaksi debet tidak ditemukan");
  }

  const gameId = String(record.gameName?.split(":")[1] || record.gameName || "").trim();

  if (gameId !== "65" && gameId !== "74") {
    throw new Error("Bukan Mahjong 1 atau 2");
  }

  const pgToken = await getAutoTokenInternal(mId, sId, gameId, domain);

  if (!pgToken) {
    throw new Error("Err Token PG");
  }

  const scatterVal = await fetchScatterFromPg(pgToken, sId, gameId);

  return {
    mId,
    sId,
    bet: record.debet,
    scatter: scatterVal,
    targetDate,
    time: record.tanggal || ""
  };
}

function getAutoTokenInternal(mId, sId, gameId, domain) {
  return new Promise((resolve) => {
    const invoice = `${sId}-${sId}-106-0`;
    const url =
      `https://${domain}/keterangan-detail.html` +
      `?playerName=${encodeURIComponent(mId)}` +
      `&invoice=${encodeURIComponent(invoice)}` +
      `&gamename=${encodeURIComponent(gameId)}` +
      `&tablekey=7`;

    chrome.tabs.create({ url, active: false }, (tab) => {
      if (!tab || !tab.id) {
        resolve(null);
        return;
      }

      const tabId = tab.id;

      const listener = (updatedTabId, info, tabObj) => {
        const currentUrl = info.url || tabObj.url || "";

        if (updatedTabId === tabId && currentUrl.includes("t=")) {
          try {
            const t = new URL(currentUrl).searchParams.get("t");

            if (t) {
              chrome.tabs.onUpdated.removeListener(listener);
              chrome.tabs.remove(tabId).catch(() => {});
              resolve(t);
            }
          } catch (err) {
            chrome.tabs.onUpdated.removeListener(listener);
            chrome.tabs.remove(tabId).catch(() => {});
            resolve(null);
          }
        }
      };

      chrome.tabs.onUpdated.addListener(listener);

      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(listener);
        chrome.tabs.remove(tabId).catch(() => {});
        resolve(null);
      }, 15000);
    });
  });
}

async function fetchScatterFromPg(pgToken, sId, gameId) {
  await new Promise(resolve => setTimeout(resolve, 2500));

  const pgUrl =
    `https://public-api.zmcyu9ypy.com/web-api/operator-proxy/v1/History/GetBetHistory` +
    `?t=${encodeURIComponent(pgToken)}`;

  const pgRes = await fetch(pgUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body:
      `sid=${encodeURIComponent(sId)}` +
      `&gid=${encodeURIComponent(gameId)}`
  });

  if (!pgRes.ok) {
    throw new Error("Gagal fetch PG History");
  }

  const pgData = await pgRes.json();

  let finalSC = "0";

  const betDetail = pgData?.dt?.bh?.bd;

  if (Array.isArray(betDetail)) {
    const scatterTrigger = betDetail.find(item => item?.gd?.nst === 21);

    if (scatterTrigger) {
      finalSC = String(scatterTrigger.gd.sc || "0");
    }
  }

  return finalSC;
}




// --- VISUAL INSPECTION LOGIC ---
const INITIAL_LOAD_DELAY = 5000;
const DELAY_TIME = 1500;


// --- SMB DASHBOARD AUTOMATION ---
async function inputToBonusDashboard(data) {
  const dashboardMId = buildDashboardMId(data.mId, data.targetDate);

  console.log("🧾 BUILD DASHBOARD MID:", {
    originalMId: data.mId,
    targetDate: data.targetDate,
    dashboardMId
  });

  const payloadForDashboard = {
    ...data,

    // simpan ID asli untuk referensi/debug
    originalMId: data.mId,

    // khusus dashboard, mId dibuat versi final
    mId: dashboardMId,

    // tetap kirim field ini juga untuk content.js baru
    dashboardMId
  };

  const targetUrl = "https://bonussmb.com/tickets";

  chrome.tabs.create({ url: targetUrl, active: false }, (tab) => {
    const tabId = tab.id;

    chrome.tabs.onUpdated.addListener(function listener(tId, info) {
      if (tId === tabId && info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(listener);

        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, {
            action: "START_AUTOMATION",
            payload: payloadForDashboard
          });
        }, 2000);
      }
    });
  });
}

function broadcastResult(result) {
  const message = { action: "BATCH_ITEM_DONE", result: result };

  // Kirim ke extension pages seperti index.html/popup.html.
  chrome.runtime.sendMessage(message).catch(() => {});

  // Tetap kirim ke content script di GAS/bonussmb agar fungsi lama tidak berubah.
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, message).catch(() => {});
    });
  });
}


// --- GOOGLE APPS SCRIPT WEB APP API BRIDGE FOR STANDALONE ADMIN PAGE ---
async function getGasConfig() {
  const cfg = await chrome.storage.local.get(['gasWebAppUrl']);
  if (!cfg.gasWebAppUrl) {
    throw new Error('Google Apps Script Web App URL belum disimpan di popup extension.');
  }
  return cfg.gasWebAppUrl;
}

async function callGasApi(action, payload = {}) {
  const gasWebAppUrl = await getGasConfig();
  const res = await fetch(gasWebAppUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify({ action, payload })
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    throw new Error(`Gagal akses Web App API: ${res.status} ${txt.slice(0, 160)}`);
  }
  const json = await res.json();
  if (!json.success) throw new Error(json.message || 'Web App API mengembalikan error');
  return json.data;
}

function toLocalDateOnly(dateStr) {
  const [y, m, d] = String(dateStr || "").split("-").map(Number);
  return new Date(y, m - 1, d);
}

function isSameLocalDate(a, b) {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

function shouldAddTS(targetDate) {
  if (!targetDate) return false;

  const inputDate = toLocalDateOnly(targetDate);
  const today = new Date();

  return !isSameLocalDate(inputDate, today);
}

function buildDashboardMId(mId, targetDate) {
  const cleanId = String(mId || "").trim();

  if (!cleanId) return cleanId;
  if (!shouldAddTS(targetDate)) return cleanId;
  if (cleanId.toUpperCase().endsWith(" TS")) return cleanId;

  return `${cleanId} TS`;
}

