// popup.js
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('statusToggle');
  const domainInput = document.getElementById('targetDomain');
  const saveBtn = document.getElementById('saveBtn');
  const openDashboardBtn = document.getElementById('openDashboardBtn');
  const statusMsg = document.getElementById('statusMsg');
  const tokenIndicator = document.getElementById('tokenIndicator');

  // 1. Load data saat popup dibuka
  chrome.storage.local.get(["extensionEnabled", "targetDomain", "token"], (data) => {
    // Set status toggle
    toggle.checked = !!data.extensionEnabled;
    updateStatusUI(data.extensionEnabled);

    // Set domain
    if (data.targetDomain) {
      domainInput.value = data.targetDomain;
    }

    // Cek apakah token sudah ter-grab otomatis
    updateTokenUI(data.token);
  });

  // 2. Fungsi Update UI Status Utama
  function updateStatusUI(isOn) {
    statusMsg.textContent = isOn ? "Sistem Aktif" : "Sistem Nonaktif";
    statusMsg.className = isOn ? "status-on" : "status-off";
  }

  // 3. Fungsi Update Indikator Token (Grabbed vs Waiting)
  function updateTokenUI(token) {
    if (token) {
      tokenIndicator.innerHTML = `<span class="indicator" style="background: #28a745;"></span> Terkoneksi`;
      tokenIndicator.style.color = "#28a745";
    } else {
      tokenIndicator.innerHTML = `<span class="indicator" style="background: #ccc;"></span> Menunggu...`;
      tokenIndicator.style.color = "#666";
    }
  }

  // 4. Listener untuk Toggle On/Off
  toggle.addEventListener('change', () => {
    const isOn = toggle.checked;
    chrome.storage.local.set({ extensionEnabled: isOn }, () => {
      updateStatusUI(isOn);
      console.log("Status ekstensi diubah ke:", isOn);
    });
  });

  // 5. Simpan Domain Target
  saveBtn.addEventListener('click', () => {
    const domain = domainInput.value.trim();
    
    if (!domain) {
      alert("Masukkan domain target terlebih dahulu!");
      return;
    }

    chrome.storage.local.set({ targetDomain: domain }, () => {
      alert("Domain berhasil disimpan!");
      // Opsional: Refresh untuk memicu grab ulang jika domain berubah
    });
  });



  // 7. Buka halaman Auto Checker (index.html) di tab extension
  openDashboardBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('index.html') });
  });

  // 6. Listener perubahan storage (untuk update status token secara real-time)
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.token) {
      updateTokenUI(changes.token.newValue);
    }
  });
});