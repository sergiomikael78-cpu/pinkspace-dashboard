console.log("🔥 RAMPOS BRIDGE ACTIVE - V2.2");

let keepAlivePort;

function ensureConnection() {
  if (!keepAlivePort) {
    try {
      keepAlivePort = chrome.runtime.connect({ name: "keepAlive" });
      keepAlivePort.onDisconnect.addListener(() => {
        console.log("⚠️ Port disconnected, reconnecting...");
        keepAlivePort = null;
        setTimeout(ensureConnection, 1000);
      });
    } catch (e) {
      console.error("Connect error:", e);
    }
  }
}

ensureConnection();

// 1. Menerima data dari GAS dan meneruskan ke Background
window.addEventListener("message", (event) => {
  if (!event.data || event.data.type !== "FROM_GAS") return;

  const payload = event.data.payload;
  console.log("✅ DATA DITERIMA DARI GAS:", payload.sId);

  ensureConnection();

  const messageToBackground = {
    action: "PROCESS_DATA",
    payload: payload
  };

  // Kita gunakan fire-and-forget untuk pengiriman awal ke background
  // agar GAS tidak tertahan menunggu status 'queued'
  chrome.runtime.sendMessage(messageToBackground, (response) => {
    if (chrome.runtime.lastError) {
      console.error("❌ RUNTIME ERROR:", chrome.runtime.lastError.message);
      sendToAllFrames({
        success: false,
        error: "Background Error: " + chrome.runtime.lastError.message,
        sId: payload.sId
      });
      return;
    }

    // CATATAN: Kita TIDAK mengirim 'response' (queued) ke GAS di sini 
    // agar GAS tetap menunggu hasil asli dari listener onMessage di bawah.
    console.log(`📥 SID ${payload.sId} sudah masuk antrean background.`);
  });
});

// 2. Menerima HASIL FINAL dari Background (Paralel)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "BATCH_ITEM_DONE") {
    console.log("🎯 HASIL FINAL SIAP, KIRIM KE GAS:", msg.result.sId);
    
    // Kirim hasil asli (yang mengandung time & scatter) ke GAS
    sendToAllFrames(msg.result);
  }
});

// Fungsi pembantu agar pengiriman ke iframe (GAS) konsisten
function sendToAllFrames(resultData) {
  const payload = { 
    type: "FROM_EXTENSION", 
    response: resultData 
  };

  // Ke window utama
  window.postMessage(payload, "*");

  // Ke semua iframe (tempat script GAS berjalan)
  const frames = window.frames;
  for (let i = 0; i < frames.length; i++) {
    try {
      frames[i].postMessage(payload, "*");
    } catch (e) {
      // Abaikan error lintas domain pada iframe lain
    }
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START_AUTOMATION") {
    console.log("🚀 Data diterima, memulai form...");
    automateForm(request.payload);
    sendResponse({ status: "Processing started" }); // Memberi sinyal balik ke background
  }
  return true; // Menjaga channel tetap terbuka
});

// content.js - Update pada bagian automateForm

async function automateForm(data) {
  const wait = (ms) => new Promise(res => setTimeout(res, ms));

  function triggerInput(el, value) {
    if (!el) return;
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function clickArrowDownAndSelect(ctrl) {
    try {
      if (!ctrl) return false;
      ctrl.click();
      await wait(300);
      const inner = ctrl.querySelector('input, [role="combobox"]');
      const target = inner || ctrl;
      target.focus();
      target.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
      await wait(200);
      target.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
      return true;
    } catch (e) { console.warn('Dropdown gagal', e); }
    return false;
  }

  console.log("🚀 Memproses Form untuk User:", data.mId);
  await wait(2000); 

  // 1️⃣ Buka Dialog (Tambah)
  const openBtn = document.evaluate(
    '//*[@id="root"]/div/main/div/div[1]/button/div',
    document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null
  ).singleNodeValue || document.querySelector('button[aria-haspopup="dialog"]');
  
  if (openBtn) openBtn.click();
  await wait(1000);

  // 2️⃣ Pilih Situs
  const situsDropdown = document.evaluate('//*[@id="radix-«r9»"]/div[2]/form/div[1]/div[2]/div', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  if (situsDropdown) await clickArrowDownAndSelect(situsDropdown);
  await wait(100);

  // 3️⃣ Pilih Tipe Games
  const tipeDropdown = document.evaluate('//*[@id="radix-«r9»"]/div[2]/form/div[2]/div[2]/div', document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  if (tipeDropdown) await clickArrowDownAndSelect(tipeDropdown);
  await wait(100);

  if (tipeDropdown) {
    await clickArrowDownAndSelect(tipeDropdown);
    console.log("Dropdown Games diinteraksi");
  }
  await wait(200);

  // 3. Isi Data mId, sId (Tiket), dan Bet

  triggerInput(document.querySelector('input[placeholder*="User ID"]'), data.mId);
  triggerInput(document.querySelector('input[placeholder*="Kode Tiket"]'), data.sId);
  triggerInput(document.querySelector('input[placeholder*="#######"]'), data.bet);


  // 4. Pilih Jumlah Scatter
  const val = parseInt(String(data.scatter).replace(/\D/g, ""));
  const containers = document.querySelectorAll('form > div');
  const scatterContainer = containers[7]; // Biasanya urutan ke-8 di form SMB
  
  if (scatterContainer) {
    const clickDiv = scatterContainer.querySelector('.select2__control');
    if (clickDiv) {
      clickDiv.click();
      await wait(250);
      const target = scatterContainer.querySelector('input') || clickDiv;
      target.focus();
      // Logic: 3 scatter = 3x ArrowUp, 4 scatter = 2x ArrowUp, 5 scatter = 1x ArrowUp
      let presses = val === 3 ? 3 : (val === 4 ? 2 : 1);
      for(let i=0; i < presses; i++) {
        target.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowUp', bubbles: true }));
        await wait(5);
      }
      target.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
    }
  }

  await wait(1000);

// 8️⃣ Klik Simpan & Ambil Status
  const saveBtn = document.querySelector('button[data-slot="button"]') || 
                  document.querySelector('button[type="submit"]');

  if (saveBtn) {
    saveBtn.click();
    console.log("Waiting for response toast...");

    // Fungsi internal untuk menunggu dan mengambil status toast
    const getFinalStatus = () => {
      return new Promise((resolve) => {
        let attempts = 0;
        const maxAttempts = 10; // Cek setiap 500ms selama 5 detik

        const interval = setInterval(() => {
          attempts++;
          const toastBox = document.querySelector('li[data-sonner-toast][data-front="true"]') || 
                           document.querySelector('li[data-sonner-toast]') ||
                           document.querySelector('[data-sonner-toast]');

          if (toastBox) {
            clearInterval(interval);
            const titleEl = toastBox.querySelector('[data-title]');
            const rawText = titleEl ? titleEl.innerText.toLowerCase() : toastBox.innerText.toLowerCase();
            const toastType = toastBox.getAttribute('data-type');

            let statusTeks = "";
            if (rawText.includes("maksimal") || rawText.includes("2x") || rawText.includes("total 2")) {
              statusTeks = "Max klaim (2x)";
            } else if (rawText.includes("jumlah scatter") || rawText.includes("kosong") || rawText.includes("benar")) {
              statusTeks = "Error input bet";
            } else if (rawText.includes("already") || rawText.includes("taken") || rawText.includes("sudah ada")) {
              statusTeks = "Sudah Di klaim";
            } else if (rawText.includes("berhasil") || rawText.includes("sukses") || toastType === "success") {
              statusTeks = "Sukses Input";
            } else if (rawText.includes("02:00 ") || toastType === "success") {
              statusTeks = "Sudah Lewat Batas Klaim Jam 2 Pagi";
            }else {
              statusTeks = "Crosscheck Ulang";
            }
            resolve(statusTeks);
          }

          if (attempts >= maxAttempts) {
            clearInterval(interval);
            resolve("Timeout (Cek Manual)");
          }
        }, 500);
      });
    };

    // Eksekusi pengambilan status
    const statusFinal = await getFinalStatus();
    console.log("🚩 Status Akhir Didapat:", statusFinal);

    // Kirim ke background
    chrome.runtime.sendMessage({
      action: "update_final_sheet", 
      timestampId: data.sId,
      statusTeks: statusFinal
    });

    // Beri jeda 1 detik agar sendMessage sampai ke background sebelum tab ditutup
    await wait(1000); 
    window.close(); 
  }
}